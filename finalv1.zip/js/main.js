window.addEventListener("load", () => {
    const currentDate = new Date();
    currentYear.innerText = currentDate.getFullYear();
});
